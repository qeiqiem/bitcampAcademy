package com.kkaekkt.biz.comm;

public class EtcVO {
	private int etcno;
	private int price;
	public int getEtcno() {
		return etcno;
	}
	public void setEtcno(int etcno) {
		this.etcno = etcno;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
}
